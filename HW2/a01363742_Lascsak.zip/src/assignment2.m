##A = [3,2; 2,1]
##
##est_cond(A)
##
##cond(A)
part1();

part2();
